# projetoRestaurante

Nosso projeto consiste na criação de um site para serviços de um restaurante, oferecendo funcionalidades como pedidos, quem somos, localização, etc. O objetivo é automatizar a gestão de um restaurante fictício, melhorando a gestão
e serviços oferecidos.

Integrantes da equipe:

- Thiago Alves Sabino
- Victor Eduardo
- Italo Wander
- Matheus Oliveira
- Walter Martins
