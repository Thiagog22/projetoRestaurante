<?php
// rodape.php
?>
<footer style="background:#111; color:#eee; padding:20px 0; margin-top:40px; text-align:center; font-family:'Poppins', Arial, sans-serif;">
    <div style="max-width:1200px; margin:auto; padding:0 20px;">
        <h3 style="margin-bottom:10px; letter-spacing:1px;">After Gastrobar</h3>
        <p style="margin-bottom:5px;">🌙 Drinks • Música • Gastronomia</p>
        <p style="margin-bottom:15px; font-size:14px; color:#bbb;">A melhor experiência noturna da cidade.</p>

        <div style="margin-bottom:15px;">
            <a href="https://www.instagram.com/aftergastrobar?utm_source=ig_web_button_share_sheet&igsh=ZDNlZDc0MzIxNw==" style="color:#f39c12; text-decoration:none; margin:0 10px;">Instagram</a>

            <a href="https://wa.me/5583999998739" style="color:#f39c12; text-decoration:none; margin:0 10px;">WhatsApp</a>
        </div>

        <p style="font-size:13px; color:#666;">© 2025 After Gastrobar – Todos os direitos reservados.</p>
    </div>
</footer>