<?php
session_start();
include "cardapio.php";

// arquivo JSON
$arquivo = "pedidos.json";
$pedidos = json_decode(file_get_contents($arquivo), true);

// ID do pedido sendo editado
$id = $_GET["id"];
$pedido = $pedidos[$id];

// Se ainda não carregamos os itens na sessão, carregamos agora
if (!isset($_SESSION["edit_temp"])) {

    $_SESSION["edit_temp"] = [
        "mesa" => $pedido["mesa"],
        "cliente" => $pedido["cliente"],
        "itens" => $pedido["itens"]
    ];
}

// ADICIONAR ITEM DURANTE EDIÇÃO
if (isset($_POST["add_item"])) {

    $categoria = $_POST["categoria"];
    $item = $_POST["item"];
    $qtd = intval($_POST["qtd"]);
    $preco = $cardapio[$categoria][$item];
    $total = $qtd * $preco;

    $_SESSION["edit_temp"]["itens"][] = [
        "categoria" => $categoria,
        "item" => $item,
        "qtd" => $qtd,
        "preco" => $preco,
        "total_item" => $total
    ];

    header("Location: editar.php?id=$id");
    exit;
}

// REMOVER ITEM
if (isset($_GET["remover_item"])) {
    $i = $_GET["remover_item"];
    unset($_SESSION["edit_temp"]["itens"][$i]);
    $_SESSION["edit_temp"]["itens"] = array_values($_SESSION["edit_temp"]["itens"]);
    header("Location: editar.php?id=$id");
    exit;
}

// SALVAR ALTERAÇÕES FINAIS
if (isset($_POST["salvar"])) {

    $_SESSION["edit_temp"]["mesa"] = $_POST["mesa"];
    $_SESSION["edit_temp"]["cliente"] = $_POST["cliente"];

    $total = 0;
    foreach ($_SESSION["edit_temp"]["itens"] as $it) {
        $total += $it["total_item"];
    }

    $pedidos[$id] = [
        "mesa" => $_SESSION["edit_temp"]["mesa"],
        "cliente" => $_SESSION["edit_temp"]["cliente"],
        "itens" => $_SESSION["edit_temp"]["itens"],
        "total" => $total,
        "data" => date("d/m/Y H:i:s")
    ];

    file_put_contents($arquivo, json_encode($pedidos, JSON_PRETTY_PRINT));

    unset($_SESSION["edit_temp"]);

    header("Location: index.php");
    exit;
}

?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
<meta charset="UTF-8">
<title>Editar Pedido</title>
<style>
    body { background:#000; color:#ffa500; font-family:Arial; padding:20px; }
    form, .box { background:#111; padding:20px; border:1px solid #ffa500; margin-bottom:20px; }
    input, select { width:100%; padding:10px; margin:5px 0 15px 0; background:#222; border:1px solid #ffa500; color:#ffa500; }
    button { background:#ffa500; color:#000; padding:10px 20px; border:none; cursor:pointer; }
    table { width:100%; border-collapse:collapse; }
    td,th { border:1px solid #ffa500; padding:10px; }
    a { color:red; }
</style>
</head>
<body>

<h1>Editar Pedido #<?= $id ?></h1>

<form method="POST">

    <label>Mesa / Endereço</label>
    <input type="text" name="mesa" value="<?= $_SESSION['edit_temp']['mesa'] ?>" required>

    <label>Cliente</label>
    <input type="text" name="cliente" value="<?= $_SESSION['edit_temp']['cliente'] ?>" required>

    <button type="submit" name="salvar">Salvar Alterações</button>
</form>

<h2>Itens do Pedido</h2>

<div class="box">
<table>
<tr>
    <th>Categoria</th>
    <th>Item</th>
    <th>Qtd</th>
    <th>Preço</th>
    <th>Total</th>
    <th>Ação</th>
</tr>

<?php
$total_geral = 0;

foreach ($_SESSION["edit_temp"]["itens"] as $index => $it):
    $total_geral += $it["total_item"];
?>
<tr>
    <td><?= $it["categoria"] ?></td>
    <td><?= $it["item"] ?></td>
    <td><?= $it["qtd"] ?></td>
    <td>R$ <?= number_format($it["preco"],2,',','.') ?></td>
    <td>R$ <?= number_format($it["total_item"],2,',','.') ?></td>
    <td><a href="editar.php?id=<?= $id ?>&remover_item=<?= $index ?>">Remover</a></td>
</tr>
<?php endforeach; ?>

<tr>
    <th colspan="4" style="text-align:right;">TOTAL GERAL:</th>
    <th colspan="2">R$ <?= number_format($total_geral,2,',','.') ?></th>
</tr>

</table>
</div>

<h2>Adicionar Novo Item</h2>

<form method="POST">

    <label>Categoria</label>
    <select name="categoria" required>
        <?php foreach ($cardapio as $c => $itens): ?>
            <option><?= $c ?></option>
        <?php endforeach; ?>
    </select>

    <label>Item</label>
    <select name="item" required>
        <?php foreach ($cardapio as $categoria => $itens): ?>
            <optgroup label="<?= $categoria ?>">
                <?php foreach ($itens as $nome => $preco): ?>
                    <option value="<?= $nome ?>"><?= $nome ?> — R$ <?= number_format($preco,2,',','.') ?></option>
                <?php endforeach; ?>
            </optgroup>
        <?php endforeach; ?>
    </select>

    <label>Quantidade</label>
    <input type="number" name="qtd" min="1" value="1">

    <button type="submit" name="add_item">Adicionar Item</button>
</form>

</body>
</html>
