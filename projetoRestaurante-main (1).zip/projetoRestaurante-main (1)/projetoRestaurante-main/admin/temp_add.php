<?php
session_start();
include "cardapio.php";

if(!isset($_SESSION["itens_temp"])) $_SESSION["itens_temp"] = [];

$_SESSION["mesa_temp"] = $_POST["mesa"];
$_SESSION["cliente_temp"] = $_POST["cliente"];

$item = $_POST["item"];
$qtd = intval($_POST["qtd"]);
$preco = 0;

// procura o preço do item
foreach($cardapio as $categoria => $itens){
    if(isset($itens[$item])){
        $preco = $itens[$item];
        break;
    }
}

$total_item = $preco * $qtd;

$_SESSION["itens_temp"][] = [
    "item" => $item,
    "qtd" => $qtd,
    "preco" => $preco,
    "total_item" => $total_item
];

header("Location: index.php");
exit;
