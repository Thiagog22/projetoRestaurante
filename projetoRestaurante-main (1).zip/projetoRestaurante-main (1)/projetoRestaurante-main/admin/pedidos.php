<?php
$arquivo = "pedidos.json";
$pedidos = file_exists($arquivo) ? json_decode(file_get_contents($arquivo),true) : [];

if(isset($_GET['excluir'])){
    $id = intval($_GET['excluir']);
    if(isset($pedidos[$id])){
        unset($pedidos[$id]);
        $pedidos = array_values($pedidos);
        file_put_contents($arquivo,json_encode($pedidos,JSON_PRETTY_PRINT));
    }
    header("Location: pedidos.php");
    exit;
}
?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
<meta charset="UTF-8">
<title>Pedidos Salvos</title>
<style>
body { background:#000; color:#ffa500; font-family:Arial; padding:20px; font-size:18px; }
h1 { font-size:28px; color:#ffa500; }
table { width:100%; border-collapse:collapse; font-size:18px; }
td,th { border:1px solid #ffa500; padding:12px; text-align:center; }
a { color:yellow; text-decoration:none; font-weight:bold; }
a:hover { color:#ffb84d; }
button { background:#ff0000; color:#fff; padding:6px 12px; border:none; cursor:pointer; border-radius:5px; }
</style>
</head>
<body>

<h1>Pedidos Salvos</h1>
<p><a href="index.php">Voltar para cadastrar</a></p>

<table>
<tr>
<th>Mesa</th>
<th>Cliente</th>
<th>Itens</th>
<th>Total</th>
<th>Data</th>
<th>Ações</th>
</tr>

<?php foreach($pedidos as $id => $p): ?>
<tr>
<td><?= $p['mesa'] ?></td>
<td><?= $p['cliente'] ?></td>
<td>
<?php foreach($p["itens"] as $i): ?>
<?= $i["qtd"] ?>× <?= $i["item"] ?><br>
<?php endforeach; ?>
</td>
<td>R$ <?= number_format($p['total'],2,',','.') ?></td>
<td><?= $p['data'] ?></td>
<td>
<a href="?excluir=<?= $id ?>" onclick="return confirm('Deseja realmente excluir este pedido?')">Excluir</a>
</td>
</tr>
<?php endforeach; ?>
</table>

</body>
</html>

