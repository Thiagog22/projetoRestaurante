<?php

$cardapio = [

    "Petiscos" => [
        "Coxinhas de Frango" => 18.99,
        "Pastéis de Carne de Sol" => 19.99,
        "Bolinho de Bacalhau" => 19.99,
        "Frango à Passarinho" => 29.99,
        "Macaxeira Frita" => 14.99,
        "Batata Frita" => 19.99,
        "Dadinho de Tapioca" => 22.99
    ],

    "Tábuas" => [
        "Cupim" => 49.99,
        "Alcatra" => 49.99,
        "Carne de Sol com Queijo" => 54.99,
        "Picanha" => 59.99,
        "4 Carnes" => 64.99
    ],

    "Espetos" => [
        "Carne" => 17.99,
        "Frango" => 13.99,
        "Linguiça" => 11.99,
        "Coração" => 12.99,
        "Charque" => 18.99
    ],

    "Pratos" => [
        "Parmegiana de Frango" => 29.99,
        "Parmegiana de Carne" => 32.99,
        "Frango ao Molho Madeira" => 32.99,
        "Carne de Sol Acebolada" => 34.99,
        "Lasanha de Frango" => 29.99,
        "Lasanha de Carne" => 32.99
    ],

    "Porções" => [
        "Arroz Branco" => 5.99,
        "Feijão Verde" => 7.99,
        "Purê de Batata" => 7.99,
        "Macaxeira" => 9.99
    ],

    "Sobremesas" => [
        "Brownie" => 11.99,
        "Brownie com Sorvete" => 14.99,
        "Taça de Açaí" => 19.99
    ],

    "Pizzas" => [
        "Mussarela" => 39.99,
        "Calabresa" => 44.99,
        "Frango com Catupiry" => 46.99,
        "Portuguesa" => 49.99,
        "4 Queijos" => 54.99
    ],

    "Hambúrgueres" => [
        "Smash Muçarela" => 18.99,
        "Smash Cheddar" => 19.99,
        "Smash Bacon" => 21.99,
        "X-Burger" => 19.99,
        "X-Salada" => 21.99,
        "X-Bacon" => 23.99
    ],

    "Drinks Alcoólicos" => [
        "Caipirinha" => 12.99,
        "Caipirosca" => 14.99,
        "Frozen" => 19.99,
        "Aperol Spritz" => 20.99,
        "Pina Colada" => 23.99,
        "Blue Lagoon" => 21.99
    ],

    "Drinks Não Alcoólicos" => [
        "Coquetel sem Álcool" => 19.99,
        "Limonada Suíça" => 12.99,
        "Soda Italiana Morango" => 14.99,
        "Soda Italiana Maçã Verde" => 14.99
    ],

    "Bebidas" => [
        "Coca-Cola Lata" => 5.99,
        "Guaraná Lata" => 5.99,
        "Fanta Laranja Lata" => 5.99,
        "Água Sem Gás" => 3.99,
        "Água Com Gás" => 4.99
    ]
];

?>
