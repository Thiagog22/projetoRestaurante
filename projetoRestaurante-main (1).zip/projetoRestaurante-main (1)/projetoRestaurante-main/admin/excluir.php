<?php

$id = $_GET['id'];

$arquivo = "pedidos.json";
$pedidos = json_decode(file_get_contents($arquivo), true);

unset($pedidos[$id]);

file_put_contents($arquivo, json_encode(array_values($pedidos), JSON_PRETTY_PRINT));

header("Location: index.php");
exit;

?>
