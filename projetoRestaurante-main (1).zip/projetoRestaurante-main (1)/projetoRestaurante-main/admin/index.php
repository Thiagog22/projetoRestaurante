<?php
session_start();
include "cardapio.php";

if (!isset($_SESSION["itens_temp"])) $_SESSION["itens_temp"] = [];

$mesa_temp = $_SESSION["mesa_temp"] ?? "";
$cliente_temp = $_SESSION["cliente_temp"] ?? "";
?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
<meta charset="UTF-8">
<title>Admin Restaurante</title>
<style>
body { background:#000; color:#ffa500; font-family:Arial; padding:20px; font-size:18px; }
h1,h2 { color:#ffa500; font-size:28px; }
form, .box { background:#111; padding:25px; border:2px solid #ffa500; border-radius:10px; margin-bottom:30px; }
input, select { width:100%; padding:12px; margin:8px 0 18px 0; background:#222; border:1px solid #ffa500; color:#ffa500; font-size:18px; border-radius:5px; }
button { background:#ffa500; color:#000; padding:12px 25px; border:none; cursor:pointer; font-size:18px; border-radius:5px; transition:0.3s; }
button:hover { background:#ffb84d; }
table { width:100%; border-collapse:collapse; font-size:18px; }
td,th { border:1px solid #ffa500; padding:12px; text-align:center; }
a { color:yellow; text-decoration:none; font-weight:bold; }
a:hover { color:#ffb84d; }
</style>
</head>
<body>

<h1>Cadastrar Pedido</h1>

<form action="temp_add.php" method="POST">
<label>Mesa / Endereço</label>
<input type="text" name="mesa" value="<?= $mesa_temp ?>" required>

<label>Cliente</label>
<input type="text" name="cliente" value="<?= $cliente_temp ?>" required>

<label>Item</label>
<select name="item" required>
<?php 
foreach($cardapio as $categoria => $itens){
    echo "<optgroup label=\"$categoria\">";
    foreach($itens as $produto => $preco){
        echo "<option value=\"$produto\">$produto — R$ ".number_format($preco,2,',','.')."</option>";
    }
    echo "</optgroup>";
}
?>
</select>

<label>Quantidade</label>
<input type="number" name="qtd" min="1" value="1" required>

<button type="submit">Adicionar item ao pedido</button>
</form>

<h2>Itens do pedido atual</h2>
<div class="box">
<?php if(count($_SESSION["itens_temp"])==0): ?>
<p>Nenhum item adicionado ainda.</p>
<?php else: ?>
<table>
<tr>
<th>Item</th>
<th>Qtd</th>
<th>Preço Unit.</th>
<th>Total Item</th>
</tr>
<?php 
$total_geral = 0;
foreach($_SESSION["itens_temp"] as $it):
    $total_geral += $it["total_item"];
?>
<tr>
<td><?= $it["item"] ?></td>
<td><?= $it["qtd"] ?></td>
<td>R$ <?= number_format($it["preco"],2,',','.') ?></td>
<td>R$ <?= number_format($it["total_item"],2,',','.') ?></td>
</tr>
<?php endforeach; ?>
<tr>
<th colspan="3" style="text-align:right;">TOTAL GERAL:</th>
<th>R$ <?= number_format($total_geral,2,',','.') ?></th>
</tr>
</table>
<?php endif; ?>
</div>

<?php if(count($_SESSION["itens_temp"])>0): ?>
<form action="salvar.php" method="POST">
<button type="submit">Salvar Pedido</button>
</form>
<?php endif; ?>

<p><a href="pedidos.php">Ver todos os pedidos</a></p>

</body>
</html>
