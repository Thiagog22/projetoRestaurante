<?php
session_start();

$mesa = $_SESSION["mesa_temp"] ?? '';
$cliente = $_SESSION["cliente_temp"] ?? '';
$itens = $_SESSION["itens_temp"] ?? [];

if(count($itens)==0){
    header("Location: index.php");
    exit;
}

$total = 0;
foreach($itens as $it){
    $total += $it["total_item"];
}

$pedido = [
    "mesa" => $mesa,
    "cliente" => $cliente,
    "itens" => $itens,
    "total" => $total,
    "data" => date("d/m/Y H:i:s")
];

$arquivo = "pedidos.json";
$lista = file_exists($arquivo) ? json_decode(file_get_contents($arquivo),true) : [];
$lista[] = $pedido;
file_put_contents($arquivo, json_encode($lista, JSON_PRETTY_PRINT));

unset($_SESSION["mesa_temp"]);
unset($_SESSION["cliente_temp"]);
unset($_SESSION["itens_temp"]);

header("Location: pedidos.php");
exit;
